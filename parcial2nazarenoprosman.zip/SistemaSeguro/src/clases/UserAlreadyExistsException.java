package clases;

public class UserAlreadyExistsException extends Exception {

	public UserAlreadyExistsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
